function create_plot_onedrugdose(input_data)
%% Plot the results as seperate subplots
% Set figure defaults (style for plotting)
load(input_data);

figure('DefaultLegendFontSize',14,'DefaultLegendFontSizeMode','manual', 'DefaultAxesFontSize', 14,'DefaultLineLineWidth', 4,'Units','normalized','Position',[0 0 1 1])
plotendtime=60*5;

% Plot NF-kB dynamics
subplot(2,4,1)
set(gca, 'ColorOrder',[0 0.7 0; 0 0.7 0],'NextPlot', 'replacechildren');
plot(t,y(:,1),':',t,y(:,2))
%xline(At,'r--','LineWidth',3);
xlabel('Time (minutes)')
ylabel('Concentration (a.u)')
legend('[NF-\kappaB_{c}]','[NF-\kappaB_{n}]','Location','northeast')
xlim([0 plotendtime])
ylim([0 2])
box on

% Plot NLRP3 dynamics
subplot(2,4,2)
set(gca, 'ColorOrder',[0 0 0.8; 0 0 0.8; 0 0 0.8], 'NextPlot', 'replacechildren');
hold on
plot(t,y(:,3),':',t,y(:,4),'-.',t,y(:,5))
plot(1*ones(1,plotendtime),'b--','LineWidth',2);
hold off
%xline(At,'r--','LineWidth',3);
xlabel('Time (minutes)')
ylabel('Concentration (a.u)')
legend('[NLRP3_{i}]','[NLRP3_{a}]','[NLRP3_{o}]','n','Location','northeast')
xlim([0 plotendtime])
ylim([0 2])
box on

% Plot ASC dynamics
subplot(2,4,3)
set(gca, 'ColorOrder',[1 0.9 0; 1 0.9 0; ],'NextPlot', 'replacechildren');
plot(t,y(:,6),':',t,y(:,7))
%xline(At,'r--','LineWidth',3);
xlabel('Time (minutes)')
ylabel('Concentration (a.u)')
legend('[ASC_{f}]','[ASC_{b}]');
xlim([0 plotendtime])
ylim([0 2])
box on
 
% Plot caspase1 dynamics
subplot(2,4,4)
set(gca, 'ColorOrder',[ 0.9 0 0; 0.9 0 0],'NextPlot', 'replacechildren');
plot(t,y(:,8),':',t,y(:,9))
%xline(At,'r--','LineWidth',3);
xlabel('Time (minutes)')
ylabel('Concentration (a.u)')
legend('[pro-C1]','[C1]');
xlim([0 plotendtime])
ylim([0 2])
box on
 
% Plot GSDMD dynamics
subplot(2,4,5)
set(gca, 'ColorOrder',[0.3 0.1 0.6; 0.3 0.1 0.6;],'NextPlot', 'replacechildren');
plot(t,y(:,10),':',t,y(:,11))
%xline(At,'r--','LineWidth',3);
xlabel('Time (minutes)')
ylabel('Concentration (a.u)')
legend('[GSDMD]','[GSDMD-N]','Location','northeast');
xlim([0 plotendtime])
ylim([0 2])
box on
 
% Plot Il-1b dynamics
subplot(2,4,6)
set(gca, 'ColorOrder',[0.3 0.4 0.1; 0.3 0.4 0.1; 0.3 0.4 0.1;],'NextPlot', 'replacechildren');
plot(t,y(:,12),':',t,y(:,13),'-.',t,y(:,14))
%xline(At,'r--','LineWidth',3);
xlabel('Time (minutes)')
ylabel('Concentration (a.u)')
legend('[pro-IL-1\beta]','[IL-1\beta_{c}]','[IL-1\beta_{e}]','Location','northeast')
xlim([0 plotendtime])
ylim([0 2])
box on
 
% Plot Il-18 dynamics
subplot(2,4,7)
set(gca, 'ColorOrder',[1 0.5 0.2; 1 0.5 0.2; 1 0.5 0.2],'NextPlot', 'replacechildren');
plot(t,y(:,15),':',t,y(:,16),'-.',t,y(:,17))
%xline(At,'r--','LineWidth',3);
xlabel('Time (minutes)')
ylabel('Concentration (a.u)')
legend('[pro-IL-18]','[IL-18_{c}]','[IL-18_{e}]','Location','northeast')
xlim([0 plotendtime])
ylim([0 2])
box on
 
% Plot Volume
subplot(2,4,8)
set(gca, 'ColorOrder',[0 0 0],'NextPlot', 'replacechildren');
hold on
plot(t,y(:,20));
plot(1.5*ones(1,plotendtime),'k--','LineWidth',2);
%xline(At,'r--','LineWidth',3);
hold off
xlabel('Time (minutes)')
ylabel('Volume')
legend('V','V_{c}','Location','northeast')
xlim([0 plotendtime])
ylim([0 2])
box on
end