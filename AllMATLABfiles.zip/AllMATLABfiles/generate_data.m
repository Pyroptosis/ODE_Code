function [t,y] = generate_data(filename_in, drug_dose)

%filename_tot='Saved_Data/'+filename_in+'.mat';

%% Set up ODE options
% Set up options to use prior to inflammasome base formation:
options1 = odeset('RelTol',1e-4,'AbsTol',1e-4,'Events', @switch_NFkB_rate);
% Set up options to use post inflammasome base formation:
options2 = odeset('RelTol',1e-4,'AbsTol',1e-4,'Events', @membrane_rupture);

%% Set initial conditions
ic_NFkB_c=0.75; % Initial conc. of cytoplasmic NF-kB 
ic_NFkB_n=0.25; % Initial conc. of nuclear NF-kB 
ic_ASC_f=1; % Initial conc. of free ASC 
ic_pro_c1=1; % Initial conc. of pro-caspase-1 
ic_GSDMD=1; % Initial conc. of (uncleaved) GSDMD 
ic_IL_18=1;  % Initial conc. of pro-IL-18
ic_V=1; % Inititial cell volume
ic_TR=drug_dose; % Initial conc. of the drug, this is a function input

% Set the initial condition vector
y0=zeros(20,1);
y0(1) = ic_NFkB_c;
y0(2) = ic_NFkB_n;
y0(6) = ic_ASC_f;
y0(8) = ic_pro_c1;
y0(10) = ic_GSDMD;
y0(15) = ic_IL_18; 
y0(18) = ic_TR;
y0(20) = ic_V;

%% Run the ODE until the first event (inflammasome base formation) occurs
% Set simulation end-time and timespan (here in minutes)
end_time = 5*60; 
tspan1 = [0 end_time];

% Set the initial step-function value F
F=1;

% Run the ODE pre event 1
[t1,y1] = ode15s(@(t1,y1) pyroptosis_ODE(y1,F), tspan1, y0, options1);

%% Run the ODE until the second event (membrane rupture) occurs
% Only do this if the first event occured before the final simulation time
if t1(end)<(end_time)
    % Adjust the timespan to start from where event 1 occured 
    tspan2 = [t1(end) end_time];
    
    % Update the step-function value F
    F=0;
    % The data at the time point where event 1 ocurred becomes the new initial condition
    y0 = y1(end,:);

    % Run the ODE post inflammasome-base formation
    [t2,y2] = ode15s(@(t2,y2) pyroptosis_ODE(y2,F), tspan2, y0, options2);

    % Merge data from pre and post inflammasome formation
    t=[t1;t2];
    y=[y1;y2];
else
        % Set 1st run solution as final solution (if 1st event doesn't occur in timeframe)
        t=t1;
        y=y1;
end

%% Save data to file after clearing unnecessary variables
clearvars -except filename_in t y 
save(filename_in);

%% Events
% Event 1: the inflammasome base is formed once [NLRP3_o] = y(5) reaches the value n.
function [value, isterminal, direction] = switch_NFkB_rate(~, y)
            n = 1; % [NLRP3_o] value reqired for inflammasome base formation
            value = (y(5) - n);
            isterminal = 1; % stop the integration
            direction = 0; % direction does not matter (default)
end
  
% Event 2: cell rupture occurs once V = y(20) reaches the critical volume. 
function [value, isterminal, direction] = membrane_rupture(~, y)
    critical_vol = 1.5; % critical volume 
    value = (y(20) - critical_vol);  
    isterminal = 1; % stop the integration.  
    direction = 0; % direction does not matter (default)
end
end
