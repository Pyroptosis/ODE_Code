% This is the main file that solves the system of ODEs (formulated in the
% pyroptosis_ODE.m) and creates data as well as single-dose plots. 

%Clear previous data and close figures
clear 
close all

%% Generate data 
%Specify data filename
data_filename = 'Saved_Data/mat100.mat';
%Specify drug dose
drug_dose = 100;
%Save the data in the data_filename
generate_data(data_filename,drug_dose);

%% Make subplots for one drug dose (Figure 3 in pre-print)
input_data = 'Saved_Data/mat100.mat';
create_plot_onedrugdose(input_data);

%% Make plots for multiple drug doses (Figure 4 in preprint)
% To make these plots, see the function create_plot_multipledrugdoses.m

clear