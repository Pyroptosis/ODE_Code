%% File to plot results of runs of the model with varying drug levels
%% Clear all presets
clear
close all
clc

%% Load data from files for each of the drug concentrations tested
load('Saved_Data/mat0.mat');
y0=y;
t0=t;
load('Saved_Data/mat25.mat');
y25=y;
t25=t;
load('Saved_Data/mat50.mat');
y50=y;
t50=t;
load('Saved_Data/mat75.mat');
y75=y;
t75=t;
load('Saved_Data/mat100.mat');
y100=y;
t100=t;
clear y t

%% Plot figure
% Plot each seperate component of the model with each of the drug
% concentrations

% set defaults
set(0, 'DefaultAxesFontSize', 12);
set(0, 'DefaultLineLineWidth', 2);

compoundlist=["[NF-\kappaB_{c}]","[NF-\kappaB_{n}]","[NLRP3_{i}]","[NLRP3_{a}]","[NLRP3_{o}]",...
    "[ASC_{f}]","[ASC_{b}]","[pro-C1]","[C1]","[GSDMD]","[GSDMD-N]",...
    "[Pro-IL-1\beta]","[IL-1\beta_{c}]","[IL-1\beta_{e}]", ...
    "[Pro-IL-18]","[IL-18_{c}]","[IL-18_{e}]", ...
    "[TR]","[TR\cdot NLRP3_{a}]","V"];
% Set figure
figure


for i = 1:20
subplot(4,5,i)
        hold on
        plot(t0,y0(:,i),'Color',[0.3,0.4,0]);
        plot(t25,y25(:,i),'Color',[0.9,0.5,0]);
        plot(t50,y50(:,i),'Color',[0.4,0.2,1]);
        plot(t75,y75(:,i),'Color',[0.0,0.3,0.9]);
        plot(t100,y100(:,i),'Color',[0.8,0,0]);
        if(i==5)
            plot(1*ones(1,60*5),'b--','LineWidth',2);
        elseif(i==20)
            plot(1.5*ones(1,60*5),'k--','LineWidth',2);
        end
        %hold off
        xlabel('Time (minutes)')
        ylabel('Concentration  (a.u)')
        title(compoundlist(i))
        xlim([0 60*5])
        if(i==18)
            ylim([0 200])
        elseif(i==19)
            ylim([0 5])
            legend('[TR](0)=0','[TR](0)=25','[TR](0)=50','[TR](0)=75','[TR](0)=100','Orientation','horizontal','Location','bestoutside')
        else 
            ylim([0 2])
        end
        %box on
end





